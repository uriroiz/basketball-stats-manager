https://gist.githubusercontent.com/uriroiz/101af7e40d78633e41a73fa1e4995c80/raw/a26890ea760cef6feabce38c916a244d9db57163/gistfile1.txt


https://fibalivestats.dcd.shared.geniussports.com/data/2759558/data.json


python -m http.server 8000
